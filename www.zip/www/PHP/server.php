<?php
$server = "localhost";
$username ="root";
$password="";
$dbname="DB";

$conn = new mysql($server,$username,$password,$dbname);
if($conn->connection_error){
	die("connection_error:" .$conn->connection_error);
}
$sql ="INSERT INTO login(username,email,password,confirm_password)"
value('dara','tol.yimdara@gmail.com',012415263,012415263)
if($conn->query($sql)== True){
	echo"New record created successfully";
}else{
	echo"Error: ".$sql. "<br>".$conn->error;
}
$conn->close();
?>