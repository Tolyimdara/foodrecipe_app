<?php

$txt = "newfile.txt";
$file = fopen($txt, "r");
$dara = substr(fgets($file),10,13);
$dara1 = substr(fgets($file),10,15);


$readdata = "Hello, I am ".$dara."and my password is ".$dara1;
echo $readdata;



?>