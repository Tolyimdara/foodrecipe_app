<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	$number =x;
	$x=10;
	echo $x;
	echo "the number is ",$number;
	
	?>

</body>
</html>