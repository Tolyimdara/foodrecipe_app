<?php
		$color= array("red","green","blue","yellow","purple");
		sort($color);
		foreach ($color as $colorr) {
			echo $colorr;
			echo "<br>";
			# code...
		}

  ?>
  <?php  
  $arr = array("red","green","blue","yellow","purple");
  $arr1 = array("red","green","blue","yellow","brown","orange");
  sort($arr1);
  for($j=0;$j<count($arr);$j++)
  {
    for($i=0;$i<count($arr1);$i++)
    {
      if($arr[$j]==$arr1[$i])
      {
        echo $arr[$j].'<br>';
      }
    }
  }
  ?>


  
  <?php 
  	for ($i=1; $i <101 ; $i++) { 
  		if ($i%15==0) {
  			echo "Sprite";
  			echo "<br>";
  			
  		}elseif($i%5==0)	
  		{
  			echo "IZE";
  			echo "<br>";

  		}elseif($i%3==0)	
  		{
  			echo "Coca_cola";
  			echo "<br>";

  		}elseif($i%3==0 && $i%5==0)
  		{
  			echo "Sprite";
  			echo "<br>";
  		}
  			else{
  			echo $i;
  			echo "<br>";


  		}
  		
  	}

   ?>