<!DOCTYPE html>
<html>
<head>
	<title>Exercise</title>
</head>
<body>
	<p>
		<?php 
			$x=1;
			while ($x <=10) {
				echo "abc,";
				$x++;
				
			}


		 ?>
	</p>
	
	<p>
		<?php 
		$x=1;
		do{
			echo "xyz,";
			$x++;
		}while ( $x< 10);


		 ?>
	</p>
	<p>
		<?php 
		for ($i=1; $i <10 ; $i++) { 
			echo $i." ";
			
		}
		 ?>
	</p>
	<p>
		<?php
		    echo "<ol>";
		for ($i='A'; $i <'G' ; $i++) { 
			
			echo "<li>.Item $i </li>";
			
			
		}
			echo "</ol>";


		 ?>
	</p>


</body>
</html>