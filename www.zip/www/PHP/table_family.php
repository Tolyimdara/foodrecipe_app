    <!DOCTYPE html>
<html>
<head>
	<title>table_family</title>
</head>
<body style="background-color: black; color: #26D4CC;">


	<?php 		

		$all = array(
			array(
			 'No'=>'1',
			 'Name'=>'Som Eurn',
			 'Gender'=>'Male',
			 'Age'=>56,
			 'Height(m)'=>1.69,
			 'Weight(kg)'=>90,
			 'color'=>'Green'

		),
		array(
			 'No'=>'2',
			 'Name'=>'Sa Veoun',
			 'Gender'=>'Female',
			 'Age'=>54,
			 'Height(m)'=>1.55,
			 'Weight(kg)'=>60,
			 'color'=>'Orange'

		),
		array(
			 'No'=>'3',
			 'Name'=>'Chan Dara ',
			 'Gender'=>'Male',
			 'Age'=>30,
			 'Height(m)'=>1.72,
			 'Weight(kg)'=>65,
			 'color'=>'Blue'

		),
		array(
			 'No'=>'4',
			 'Name'=>'Chan Thyda',
			 'Gender'=>'Female',
			 'Age'=>27,
			 'Height(m)'=>1.60,
			 'Weight(kg)'=>61,
			 'color'=>'Red'

		),
		array(
			 'No'=>'5',
			 'Name'=>'Chan Siheng',
			 'Gender'=>'Female',
			 'Age'=>25,
			 'Height(m)'=>1.65,
			 'Weight(kg)'=>70,
			 'color'=>'Yellow'

		),
		array(
			 'No'=>'6',
			 'Name'=>'Chan Bopha',
			 'Gender'=>'Female',
			 'Age'=>20,
			 'Height(m)'=>1.60,
			 'Weight(kg)'=>46,
			 'color'=>'Pink'
			)
		);

		
	 ?>
	 	
	 	<?php 
	 			$ram1=array_rand($all,1);
	 			

	 	 ?>
	 	 <br>
	 	 <table rules="all" border="1" style="width: 500px; height: auto; text-align: center;" bgcolor="<?php echo $all[$ram1]['color'];  ?>" >
	 	 	<tr>

	 	 		<td>No</td>
	 	 		<td><?php echo $all[$ram1]['No'];	  ?></td>
	 	 		
	 	 	</tr>
	 	 	<tr>
	 	 		<td>Name</td>
	 	 		<td><?php echo $all[$ram1]['Name'];	 ?></td>
	 	 	</tr>
	 	 	<tr>
	 	 		<td>Age</td>
	 	 		<td><?php echo $all[$ram1]['Age'];	 ?></td>
	 	 	</tr>
	 	 	<tr>
	 	 		<td>Gender</td>
	 	 		<td><?php echo $all[$ram1]['Gender'];	 ?></td>
	 	 	</tr>
	 	 	<tr>
	 	 		<td>Height</td>
	 	 		<td><?php echo $all[$ram1]['Height(m)'];	 ?></td>
	 	 	</tr>
	 	 	<tr>
	 	 		<td>Weight</td>
	 	 		<td><?php echo $all[$ram1]['Weight(kg)'];	 ?></td>
	 	 	</tr>
	 	 	

	 	 </table>
	 	 <br>
	 	 <table >
	 	 	<tr>
	 	 		<td>
	 	  <?php
			$BMI= $all[$ram1]['Weight(kg)']/(($all[$ram1]['Height(m)'])*($all[$ram1]['Height(m)']));
			$re="";
			$color="";
			
			  if($BMI < 18.5){	
			    $re=$all[$ram1]['Name']."is Underweight";
			    $color="Red";
			  }
			  else if ($BMI >= 18.5 && $BMI <= 24.9){
			    $re=$all[$ram1]['Name']."is Normalweight";
			    $color="Green";
			  }
			  else if ($BMI >25 && $BMI <= 29.9){
			    $re=$all[$ram1]['Name']."is Overweight";
			    $color="Blue";
			  }
			  else{
			    $re=$all[$ram1]['Name']."is Obesity";
			    $color="Brown";
			  }

	 	  ?>
	 	  </td>
	 	  </tr>
	 	  <p style="background-color: <?php echo $color; ?>">
	 	  	<?php  echo $re; ?>
	 	  </p>

	 	  </table>
	 	

	 	
</body>
</html>