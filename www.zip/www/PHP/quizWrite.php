<?php
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "Username:Dara\n"."\r\n";
fwrite($myfile, $txt);

$txt = "Password:123456\n"."\r\n";
fwrite($myfile, $txt);
fclose($myfile);
?>