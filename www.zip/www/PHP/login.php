<?php
  session_start();
  $base=mysqli_connect('localhost','root','','people');
  if(!$base)
  {
    echo "fail";
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- <script >
	var attempt = 3;
	function validate(){
	var name = "<?php echo $name; ?>";
	var password = "<?php echo $password; ?>";
	if ( name = $name && password = $password ){
	alert ("Login successfully");
	window.location = "C:\wamp64\www\PHP\success.php"; 
	return false;
	}
	else{
	attempt--;
	alert("You have left "+attempt+" attempt;");
	
	if( attempt == 0){
	document.getElementById("email").disabled = true;
	document.getElementById("password").disabled = true;
	document.getElementById("submit").disabled = true;
	return false;
	}
	}
}
</script> -->
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body style="background-image:url(80305876_3059546550739379_7684138036656865280_n.jpg); ">
	<section>
		
            <div class="contact-form" style="background-color: #ccffcc;">
        <form action="login.php" method="post" onsubmit="return validate()" >
            <h1>Login</h1>
            <div class="txtb">
                <label style="color: red" for="name">Name: </label>
                <input type="text" style="color: white;" name="name" placeholder="Enter Your name " id="email">
           
            </div>
            <div class="txtb">
                <label style="color: red;" for="password">Password: </label>
                <input type="text" style="color: white;" name="password" placeholder="Enter Your Password" id="password">
                
            </div>
            
            <input type="submit" value="Login" class="btN" id="submit" name="submit"/>
            <div>
            
        </div>
        </form>
        		<a href="login2.php"><input type="submit" class="btN" value="Sign up"></a>
    </div>
    </section>

</body>
</html>
<?php
  $errors = array();
  if (isset($_POST['submit'])) 
  {
    $name=$_POST['name'];
    $password=$_POST['password'];
    $username = mysqli_real_escape_string($base, $_POST['name']);
    $password = mysqli_real_escape_string($base, $_POST['password']);

    if (empty($name)) {array_push($errors, "Username is required");}
    if (empty($password)) {array_push($errors, "Password is required");}

    if (count($errors) == 0) 
    {
      $query = "SELECT * FROM login WHERE Username='$username' AND Password='$password'";
      $results = mysqli_query($base, $query);
      
      if (mysqli_num_rows($results) == 1) 
      {
        $_SESSION['Username'] = $username;
        header('location: success.php');
      }else 
      {
        array_push($errors, "ខុសហើយ,អញើញវាយសារជាថ្មី");
        echo "ខុសហើយ,អញើញវាយសារជាថ្មី";
      }
    }
  }
?>