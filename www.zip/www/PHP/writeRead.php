<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php
$txt = "newfile.txt";
$file = fopen($txt, "r");
$dara1 = fgets($file)."\r\n";
$dara2 = fgets($file)."\r\n";
fclose($file);
$txt = "newfile.txt";
$file = fopen($txt, "w");
$read = "Hello my name is Leeminra"."\r\n";
fwrite($file, $read);
fwrite($file, $dara1);
fwrite($file, $dara2);
fclose($file);

}

?>

</body>
</html>