<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST">
	    <input type="text" name="username">
	    <input type="text" name="pass">
	    <input type="submit" name="btnshow" value="login"></a>
	    <input type="submit" name="btnshow1" value="register">
   	</form>
	<?php 
	if(isset($_POST['btnshow']))
	{
		$name=$_POST['username'].' '.$_POST['pass'];
        $file= file("file.txt");
       if(!($file))
       {
       		echo "Cant not find file";
       }else
       {
       		for($i=0;$i<count($file);$i++)
       		{
       			if($file[$i]==$name)
       			{
       				echo "right";
       			}else
       			{
       				echo "wrong";
       			}
       		}
       }
	}
	?>
</body>
</html>