
 <!DOCTYPE html>
 <html>
 <head>
     <title></title>
 </head>
 <body>
    <form method="post">
        <input type="text" name="username">
        <input type="text" name="pass">
        <input type="submit" name="btnshow1" value="register">
        <a href="test1.php"><input type="submit" value="login"></a>
    </form>
<?php 
    if(isset($_POST['btnshow1']))
    {
        $name=$_POST['username'].' '.$_POST['pass'];
        $file= fopen("file.txt","a");
        fwrite($file,$name."\n");
        fclose($file);
    }
 ?>
 </body>
 </html>
 