<?php
  $errors = array();
  if (isset($_POST['submit'])) 
  {
    $name=$_POST['username'];
    $pass=$_POST['pass'];
    if($name=="admin" && $pass=="admin")
    {
      $_SESSION['username'] = "admin";
      $_SESSION['success'] = "You are now logged in";
      header('location: In.php');
    }

    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['pass']);

    if (empty($username)) {array_push($errors, "Username is required");}
    if (empty($password)) {array_push($errors, "Password is required");}

    if (count($errors) == 0) 
    {
      $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
      $results = mysqli_query($db, $query);
     
      if (mysqli_num_rows($results) == 1) 
      {
        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: In.php');
      }else 
      {
        array_push($errors, "Wrong username/password combination");
        echo "Wrong username/password combination";
      }
    }
  }
?>