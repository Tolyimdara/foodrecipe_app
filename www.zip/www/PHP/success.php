<?php
	session_start();
	$base = mysqli_connect("localhost","root","","people");
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>HOME PAGE</title>
</head>
<body>
	<p style="font-size: ">Welcome and good bye</p>
	<form method="post">
		<div >
	        <input type="submit" name="submit" value="Logout" style="background-color: #17a2b8; color: white; width: 100%; height: auto; font-size: 50px;">
	    </div>
    </form>
	<?php
		if (isset($_POST['submit'])) {
		 	session_destroy();
		 	header("location: login.php");
		 } 
	?>
</body>
</html>