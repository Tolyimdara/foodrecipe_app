	<?php

	class ClassDB{

		public $servername = "localhost";
		public $username = "root";
		public $password = "";
		public $dbname = "Dara";
		public function ClassDB(){

    		try {  
      			$connection = new PDO("mysql:host=$this->servername;dbname=$this->dbname",$this->username, $this->password);
    			  $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);;  
      			echo "Success!"; 
            $connection = null;
    		}
    		catch(PDOException $abc) {  
				echo 'ERROR: ' . $abc->getMessage();
				echo "Connection-Failed! ";
				echo "try_again";
    		} 

  		}
 	}
 	$return = new ClassDB(); 
  $return->ClassDB();
?>

