<?php
  session_start();
  $base=mysqli_connect('localhost','root','','people');
  if(!$base)
  {
    echo "fail";
  }
?>  
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="login.css">
    <script >
    function signUp() {  
        var name = document.getElementById('name').value;
        var email =document.getElementById('email').value;
        var Password = document.getElementById('Password').value;
        var confirm_passsword =document.getElementById('confirm_password').value;
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var valid=true;
        if (name=="") {
            valid=false;
            document.getElementById('name_error').innerHTML="required";
        }
        if (email=="") {
            valid=false;
            document.getElementById('email_error').innerHTML="required";
        }
        if (Password=="") {
            valid=false;
            document.getElementById('Password_error').innerHTML="required";
        }
        if (confirm_password=="") {
            valid=false;
            document.getElementById('confirm_Password_error').innerHTML="required";
        } 
            return valid;
            event.preventDefault(); 

    }
</script>
</head>
<body style="background-image:url(80305876_3059546550739379_7684138036656865280_n.jpg); ">
  <section>
            <div class="contact-form" style="background-color: #ccffcc;" >
        <form action="" method="POST" action="login2.php" onsubmit="return signUp()" >
            <h1>Sign Up</h1>          
            <div class="txtb">
                <label style="color: red"  >Name: </label><span id="name_error"></span>
                <input type="text" style="color: white;" name="name" id="name" placeholder="Enter Your Name" >
            </div>
            <div class="txtb">
                <label style="color: red;" >Email: </label><span id="email_error" ></span>
                <input type="email" style="color: white;" name="email" id="email" placeholder="Enter Your Email ID">
            </div>
            <div class="txtb">
                <label style="color: red" >Password: </label><span id="Password_error"></span>
                <input type="text" style="color: white;" name="password" id="Password" placeholder="Enter Your Password">
            </div>
            <div class="txtb">
                <label style="color: red" >Confirm Password: </label><span id="confirm_Password_error"></span>
                <input type="text" style="color: white;" name="confirm_password" id="confirm_password" placeholder="Re-enter your Password">
            </div>
        
            <input type="submit" value="Sign Up" name="submit" class="btN">
        </form>
    </div>
    </section>


</body>
</html>
<?php
  $error = array();
  if(isset($_POST['submit']))
  {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password= $_POST['confirm_password'];
    if(empty($name)) {array_push($error,"Username required");}
    if(empty($email)) {array_push($error,"Email required");}
    if(empty($password)) {array_push($error,"Password required");}
    if($password != $confirm_password) {array_push($error,"These two password not match each other");}

      $user_check_query = "SELECT * FROM login WHERE Username='$name' OR Email='$email' LIMIT 1";
      $result = mysqli_query($base, $user_check_query);
      $user = mysqli_fetch_assoc($result);
  
      if ($user) 
      {
         if ($user['Username'] === $name) 
         {
            array_push($error, "Username already exists");
            
        }
      if ($user['Email'] === $email) 
      {
            array_push($error, "email already exists");
        }
      }

      if (count($error) == 0) 
      {
        $query = "INSERT INTO login (Username,Email,Password,Confirm_password)VALUES('$name', '$email', '$password','$confirm_password')";
        if (mysqli_query($base, $query)) 
        {
              $_SESSION['Username'] = $name;
              $_SESSION['success'] = "You are now logged in";
              header('location: login.php');
      } 
      else 
      {
          echo "Error: ". $query . " " . mysqli_error($base); 
      }
      }
  }
?>