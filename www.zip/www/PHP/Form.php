<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php
	$cities=array("japan" =>"Toyko" ,"Mexico City"=>"Mexico","New York City"=>"USA" ,"Mumbai"=>"India","Seoul"=>"Korea","Shanghai"=>"China","Lagos"=>"Nigeria","Buenos Aries"=>"Argentina","Cairo"=>"Egypt","London"=>"England");  


	?>
	<form action="#" method="post">
	<select name="cities[]" multiple> 
	<option value="japan">japan</option>
	<option value="Mexico">Mexico</option>
	<option value="New York City">New York</option>
	<option value="Mumbai">Mumbai</option>
	<option value="Seoul">Seoul</option>
	<option value="Shanghai">Shanghai</option>
	<option value="Lagos">Lagos</option>
	<option value="Buenos Aries">Bueonos Aries</option>
	<option value="New York City">New York</option>
	<option value="Mumbai">Mumbai</option>
	<option value="Seoul">Seoul</option>
	</select>
	<input type="submit" name="submit" value="Get Selected Values" />
	</form>
	<?php
	if(isset($_POST['submit'])){
	
	foreach ($_POST['cities'] as $select)
	{
	echo "You have selected :" .$select; 
	}
	?>

</body>
</html>