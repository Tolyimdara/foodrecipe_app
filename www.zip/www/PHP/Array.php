<!DOCTYPE html>
<html>
<head>
	<title>Php</title>
</head>
<body>
	<ol>
		<?php  

		$name="Tol Yimdara";
		$number=5545;
		var_dump($name,$number);

		$student= array("sok" => 50,"Dara" => 40, "Ace" => 50);
		echo $student["Dara"];












		?>
		





	</ol>

</body>
</html>