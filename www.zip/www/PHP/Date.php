<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	
	<?php 
		$month= date('F',time());
		if ($month=="August") {
			echo "So it is really hot";

		}else{
			echo "Not August, so at least not in the peak of the heat";
		}

	 ?>

</body>
</html>