<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		function count($int a, $int b){
			
		}


	 ?>

</body>
</html>