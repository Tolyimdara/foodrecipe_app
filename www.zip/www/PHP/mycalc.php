<?php 
class mycalc{
    private $n1 , $n2;

    public function __construct($val1, $val2){
        $this->n1 = $val1;
        $this->n2 = $val2;
    }

    public function add(){
        return $this->n1 + $this->n2;
    }

    public function subtract(){
        return $this->n1 - $this->n2;
    }

    public function multiply (){
        return $this->n1 * $this->n2;
    }

    public function divide () {
        return $this->n1 / $this->n2;
    }
}


$calc = new mycalc(12,6);
echo "<p>12 + 6 = ".$calc->add(). "</p>";

$calc = new mycalc (12,6);
echo "<p>12 - 6 = ".$calc->subtract(). "</p>";

$calc = new mycalc (12,6);
echo "<p> 12 * 6 = ".$calc->multiply(). "</p>";

$calc = new mycalc (12,6);
echo "<p> 12 / 6 = ".$calc ->divide(). "</p>";
 ?>