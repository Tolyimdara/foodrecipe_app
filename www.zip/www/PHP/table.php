<!DOCTYPE html>
<html>
<head>
	<title>table</title>
</head>
<body>
	
<!-- <div style="text-align: center;background-color: yellow;width: 500px;"> -->
	<table border="1" rules="all" style="width: 100%; height: 200px; background-color: red;text-align: center;">
        <?php 
          for ($i=1; $i < 8; $i++) { 
            echo "<tr>";
            for ($j=1; $j < 8; $j++) { 
              echo "<td>";
              $x = $j * $i;
              echo $x;
              echo "</td>";
            }
            echo "</tr>";
          }
         ?>
    </table>
    </div>
    </div>

</body>
</html>